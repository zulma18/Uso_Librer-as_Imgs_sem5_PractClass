package com.example.practclass_libreras_imgs_sem5_dama

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ViewFlipper
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var viewFlipper: ViewFlipper
    private lateinit var button: Button
    private lateinit var dotsLayout: LinearLayout
    private val handler = Handler(Looper.getMainLooper())
    private var currentIndex = 0
    private val imagesCount = 7  // Número total de imágenes en el ViewFlipper

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Inicializando los componentes
        viewFlipper = findViewById(R.id.viewFlipper)
        button = findViewById(R.id.btn_enlaces)
        dotsLayout = findViewById(R.id.indicadores)

        // Crear los dots
        createDots()

        // Configurando el ViewFlipper
        viewFlipper.setAutoStart(false)  // No inicia automáticamente
        viewFlipper.setFlipInterval(3000)
        viewFlipper.setInAnimation(this, android.R.anim.fade_in)
        viewFlipper.setOutAnimation(this, android.R.anim.fade_out)

        // Iniciar el slider de imágenes automáticamente
        startImageFlipping()

        // Configurar el botón para abrir la URL
        button.setOnClickListener {
            val url = "https://www.vidaextra.com/guias-y-trucos/todas-peliculas-spider-man-orden"
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            startActivity(intent)
        }
    }

    private fun createDots() {
        dotsLayout.removeAllViews()  // Limpiar dots previos

        for (i in 0 until imagesCount) {
            val dot = ImageView(this)
            dot.setImageResource(if (i == 0) R.drawable.dot_active else R.drawable.dot_inactive)

            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            params.setMargins(8, 0, 8, 0)
            dot.layoutParams = params

            dotsLayout.addView(dot)
        }
    }

    private fun updateDots() {
        for (i in 0 until imagesCount) {
            val dot = dotsLayout.getChildAt(i) as ImageView
            dot.setImageResource(if (i == currentIndex) R.drawable.dot_active else R.drawable.dot_inactive)
        }
    }

    private fun startImageFlipping() {
        handler.postDelayed(object : Runnable {
            override fun run() {
                currentIndex = (currentIndex + 1) % imagesCount
                viewFlipper.showNext()
                updateDots()
                handler.postDelayed(this, 3000)
            }
        }, 3000)
    }
}
